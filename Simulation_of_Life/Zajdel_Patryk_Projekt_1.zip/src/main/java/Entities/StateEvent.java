package Entities;

public class StateEvent {
    public final String stateName;

    public StateEvent(String stateName) {
        this.stateName = stateName;
    }

}
