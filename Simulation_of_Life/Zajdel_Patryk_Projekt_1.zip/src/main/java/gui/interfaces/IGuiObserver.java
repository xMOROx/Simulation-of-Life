package gui.interfaces;

public interface IGuiObserver {
    void updateGuiMap();

    void updateGuiCharts();
}
