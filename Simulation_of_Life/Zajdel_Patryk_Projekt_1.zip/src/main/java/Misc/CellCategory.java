package Misc;

public enum CellCategory {
    FIRST,
    SECOND,
}
